from django.shortcuts import render
from .models import scrumboard
# Create your views here.
from django.template.loader import render_to_string
