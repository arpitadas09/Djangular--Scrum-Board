(function () {
    'use strict';

    angular
        .module('scrumboard.demo')
        .service('Login', ['$http', '$location','$window', Login]);


    function Login($http, $location,$window) {
        this.login = login;
        this.isLoggedIn = isLoggedIn;
        this.logout = logout;
        this.redirectIfNotLoggedIn = redirectIfNotLoggedIn;

        function login(credentials) {
            return $http.post('/auth_api/login/', credentials)
                .then(function (response) {
                    //$window.localStorage.setItem('currentUser',JSON.stringify(response.data));
                    $window.localStorage.currentUser = JSON.stringify(response.data);
                });
        }

        function isLoggedIn(){
            return $window.localStorage.currentUser;
        }

        function logout() {
            delete $window.localStorage.currentUser;
            $http.get('/auth_api/logout/').then(function(){
                $location.url('/login');
               });

        }
        function redirectIfNotLoggedIn() {
            if(!isLoggedIn()) {
                $location.url('/login');
             }
         }
    }


})();
